﻿
#define srccols 1626
#define srcrows 196
#define maxline 10
#include <stdio.h>
#include <iostream>
#include <stdio.h>
#include <opencv.hpp>
#include <opencv2/highgui/highgui.hpp>  
#include "opencv2/objdetect/objdetect.hpp"
#include <opencv2/imgproc/imgproc.hpp>  
#include <opencv2/core/core.hpp>  
#include <highgui.h> 
#include <pylon/PylonIncludes.h>
#ifdef PYLON_WIN_BUILD
#    include <pylon/PylonGUI.h>
#endif
#define USE_GIGE 1
using namespace Pylon;
using namespace GenApi;
using namespace std;
using namespace cv;  
