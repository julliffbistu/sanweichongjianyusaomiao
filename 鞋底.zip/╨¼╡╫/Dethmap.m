function Dethmap(name,low,high)
 
close all
Dimg=csvread(name,1,1);
%%%Dimg=Dimg(1:end-500,200:end-200);
 Dimg= Cutimg( Dimg,low,high );
%%%
% sigma = 1.6;
% //gausFilter = fspecial('gaussian',[5 5],sigma);
% Dimg=imfilter(Dimg,gausFilter,'replicate');
surf(Dimg,'EdgeColor','None');%����z��3Dͼ
shading interp;
% fid1=fopen([ '2c.txt'],'w');%write ��ʽ��һ���ļ�
end


