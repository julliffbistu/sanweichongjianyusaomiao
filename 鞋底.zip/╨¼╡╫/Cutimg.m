function [ img ] = Cutimg( img,min,max )
 for i=1:size(img,1)
     for j=1:size(img,2)
         if img(i,j)>max
           img(i,j)=max; 
         elseif img(i,j)<min
            img(i,j)=min; 
         end
     end
 end


end

